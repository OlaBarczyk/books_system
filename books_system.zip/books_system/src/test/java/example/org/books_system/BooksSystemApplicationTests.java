package example.org.books_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooksSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}

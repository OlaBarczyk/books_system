package example.org.books_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BooksSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(BooksSystemApplication.class, args);
	}

}
